from easytask.easyTask import Runnable
from easytask.task import Task
